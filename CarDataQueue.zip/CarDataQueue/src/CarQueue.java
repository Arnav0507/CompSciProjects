import java.io.*;
import java.util.*;

public class CarQueue{
    public static void main(String[] args) {
        File file = new File("/Users/arnavgoel/IdeaProjects/CarDataQueue/src/CarData.txt");
        Stack<Car> carStack = new Stack<>();
        Queue<Car> carQueue = new LinkedList<>();
        PriorityQueue<Car> carPriorityQueue = new PriorityQueue<>();
        try{
            BufferedReader reader = new BufferedReader(new FileReader(file));
            String text;
            boolean first = true;
            while ((text = reader.readLine()) != null) {
                if(first){
                    first = false;
                }
                else{
                    String[] list = text.split("\t");
                    int[] intList = new int[list.length];
                    for(int i = 0; i < list.length; i++){
                        intList[i] = Integer.parseInt(list[i]);
                    }
                    Car car = new Car(intList[0],intList[1],intList[2],intList[3],intList[4],intList[5],intList[6],intList[7]);
                    carStack.add(car);
                    carQueue.add(car);
                    carPriorityQueue.add(car);
                }
            }
            System.out.println("Car Stack:");
            System.out.println(String.format("%-25s %-25s %-25s %-25s %-25s %-25s %-25s %-25s", "carId", "milesPerGallon", "engineSize", "horsePower", "weight", "acceleration", "country", "numCylinders"));
            while(!carStack.isEmpty()){
                System.out.println(carStack.pop());
            }
            System.out.println("\nCar Queue:");
            System.out.println(String.format("%-25s %-25s %-25s %-25s %-25s %-25s %-25s %-25s", "carId", "milesPerGallon", "engineSize", "horsePower", "weight", "acceleration", "country", "numCylinders"));
            while(!carQueue.isEmpty()){
                System.out.println(carQueue.poll());
            }
            System.out.println("\nCar Priority Queue:");
            System.out.println(String.format("%-25s %-25s %-25s %-25s %-25s %-25s %-25s %-25s", "carId", "milesPerGallon", "engineSize", "horsePower", "weight", "acceleration", "country", "numCylinders"));
            while(!carPriorityQueue.isEmpty()){
                System.out.println(carPriorityQueue.poll());
            }
        }
        catch(IOException e){

        }
    }



    static class Car implements Comparable<Car>{
        int carId;
        int milesPerGallon;
        int engineSize;
        int horsePower;
        int weight;
        int acceleration;
        int country;
        int numCylinders;

        public Car(int carId, int milesPerGallon, int engineSize, int horsePower, int weight, int acceleration, int country, int numCylinders){
            this.carId = carId;
            this.milesPerGallon = milesPerGallon;
            this.engineSize = engineSize;
            this.horsePower = horsePower;
            this.weight = weight;
            this.acceleration = acceleration;
            this.country = country;
            this.numCylinders = numCylinders;
        }

        public String toString(){
            return String.format("%-25s %-25s %-25s %-25s %-25s %-25s %-25s %-25s", carId, milesPerGallon, engineSize, horsePower, weight, acceleration, country, numCylinders);
        }

        @Override
        public int compareTo(Car o) {
            if(o.acceleration!=this.acceleration)
                return o.acceleration > this.acceleration ? 1 : -1;
            else if(o.milesPerGallon!=this.milesPerGallon)
                return o.milesPerGallon > this.milesPerGallon ? 1 : -1;
            else if(o.horsePower!=this.horsePower)
                return o.horsePower > this.horsePower ? 1 : -1;
            else if(o.engineSize!=this.engineSize)
                return o.engineSize > this.engineSize ? 1 : -1;
            else if(o.weight!=this.weight)
                return o.weight > this.weight ? 1 : -1;
            else if(o.numCylinders!=this.numCylinders)
                return o.numCylinders > this.numCylinders ? 1 : -1;
            else if(o.carId!=this.carId)
                return o.carId > this.carId ? 1 : -1;
            else{
                return 0;
            }
        }
    }
}