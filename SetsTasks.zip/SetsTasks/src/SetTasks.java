import java.util.*;
public class SetTasks {
    public static void main(String[] args) {
        ArrayList<HashSet<Integer>> list = new ArrayList<>();
        int randomLength = (int)(Math.random()*11) + 2;
        for(int i = 0; i < randomLength; i++){
            HashSet<Integer> hashSet = new HashSet<>();
            for(int j = 0; j < 10; j++){
                int randomVal = (int)(Math.random()*20) + 1;
                if(!hashSet.contains(randomVal)) {
                    hashSet.add(randomVal);
                }
                else{
                    j--;
                }
            }
            list.add(hashSet);
        }
        System.out.println(list);
        System.out.println("Set 1: " + list.get(0));
        System.out.println("Set 2: " + list.get(1));
        System.out.println("Intersection: " + getIntersection(list.get(0), list.get(1)));
        System.out.println("Union: " + getUnion(list.get(0), list.get(1)));
        System.out.println("Even Intersection: " + getEvenIntersection(list.get(0), list.get(1)));
        System.out.println("Even Union: " + getEvenUnion(list.get(0), list.get(1)));

    }

    public static HashSet<Integer> getIntersection(HashSet<Integer> set1, HashSet<Integer> set2){
        HashSet<Integer> intersection = new HashSet<>();
        Iterator<Integer> it = set1.iterator();
        while(it.hasNext())
        {
            int val = it.next();
            if(set2.contains(val)){

                intersection.add(val);

            }
        }
        return intersection;

    }

    public static HashSet<Integer> getUnion(HashSet<Integer> set1, HashSet<Integer> set2) {
        HashSet<Integer> union = new HashSet<>();
        Iterator<Integer> it = set1.iterator();
        while(it.hasNext())
        {
            int val = it.next();
            if(!set2.contains(val)){

                union.add(val);

            }
        }
        Iterator<Integer> it2 = set2.iterator();
        while(it2.hasNext())
        {
            int val = it2.next();
            if(!set1.contains(val)){

                union.add(val);

            }
        }
        return union;
    }
    public static HashSet<Integer> getEvenIntersection(HashSet<Integer> set1, HashSet<Integer> set2){
        HashSet<Integer> intersection = new HashSet<>();
        Iterator<Integer> it = set1.iterator();
        while(it.hasNext())
        {
            int val = it.next();
            if(set2.contains(val)){

                intersection.add(val);

            }
        }
        HashSet<Integer> evenIntersection = new HashSet<>();
        Iterator<Integer> it2 = intersection.iterator();
        while (it2.hasNext()){
            int val = it2.next();
            if(val%2 == 0){

                evenIntersection.add(val);

            }
        }
        return evenIntersection;

    }

    public static HashSet<Integer> getEvenUnion(HashSet<Integer> set1, HashSet<Integer> set2) {
        HashSet<Integer> union = new HashSet<>();
        Iterator<Integer> it = set1.iterator();
        while(it.hasNext())
        {
            int val = it.next();
            if(!set2.contains(val)){

                union.add(val);

            }
        }
        Iterator<Integer> it2 = set2.iterator();
        while(it2.hasNext())
        {
            int val = it2.next();
            if(!set1.contains(val)){

                union.add(val);

            }
        }
        HashSet<Integer> evenUnion = new HashSet<>();
        Iterator<Integer> it3 = union.iterator();
        while (it3.hasNext()){
            int val = it3.next();
            if(val%2 == 0){

                evenUnion.add(val);

            }
        }
        return evenUnion;
    }

}