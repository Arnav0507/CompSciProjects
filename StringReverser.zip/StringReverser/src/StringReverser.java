import java.util.Stack;

public class StringReverser {
    public static void main(String[] args) {
        final String theString = "Brazil is winning the world cup";//YOU CHOOSE

        Stack<Character> stack = new Stack<>();
        for(int i = 0; i < theString.length(); i++){
            stack.push(theString.charAt(i));
        }
        while(!stack.isEmpty()){
            System.out.print(stack.pop());
        }
    }
}